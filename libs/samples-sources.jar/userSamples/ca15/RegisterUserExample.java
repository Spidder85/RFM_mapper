/**
 * Copyright 2004-2012 Crypto-Pro. All rights reserved.
 * Программный код, содержащийся в этом файле, предназначен
 * для целей обучения. Может быть скопирован или модифицирован
 * при условии сохранения абзацев с указанием авторства и прав.
 *
 * Данный код не может быть непосредственно использован
 * для защиты информации. Компания Крипто-Про не несет никакой
 * ответственности за функционирование этого кода.
 */
package userSamples.ca15;

import ru.CryptoPro.JCP.Util.JCPInit;
import ru.CryptoPro.JCPRequest.ca15.decoder.CA15UserRegistrationField;
import ru.CryptoPro.JCPRequest.ca15.request.CA15GostCertificateRequest;
import ru.CryptoPro.JCPRequest.ca15.status.CA15Status;
import ru.CryptoPro.JCPRequest.ca15.status.CA15UserRegisterInfoStatus;
import ru.CryptoPro.JCPRequest.ca15.status.CA15UserRegisterStatus;
import ru.CryptoPro.JCPRequest.ca15.user.CA15User;

import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

/**
 * Пример получения списка полей для подготовки регистрации пользователя,
 * заполнения полей, отправки запрос на регистрацию, проверки статуса
 * регистрации пользователя.
 *
 * 10/11/2012
 *
 */
public class RegisterUserExample extends CAConfiguration {

    /**
     * Конструктор.
     *
     * @param needInit Флаг необходимости выполнить
     * инициализацию.
     */
    protected RegisterUserExample(boolean needInit) {
        super(needInit);
    }

    /**
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        JCPInit.initProviders(false);
        final RegisterUserExample example = new RegisterUserExample(true);
        example.main();

    }

    /**
     * Вывод информации о пользователе и статусе.
     *
     * @param userInfo Данные пользователя.
     * @param userStatus Статус пользователя.
     */
    public static void printUserInfo(CA15User userInfo,
        CA15UserRegisterStatus userStatus) {

        System.out.println("SAVE tokenID AND password TO CONFIGURATION!");
        System.out.print("User: ");
        System.out.print("\n\ttokenID: " + userInfo.getTokenID());
        System.out.print("\n\tpassword: " + userInfo.getPassword());
        System.out.print("\n\tstatus: " + userStatus.toString());
        System.out.println("\n\tregistration identifier: " + userStatus.getRegistrationId());
    }

    /**
     * Функция вывода списка полей с их параметрами.
     *
     * @param index Номер поля.
     * @param field Описание поля.
     */
    public static void printUserRegistrationFieldInfo(int index,
        CA15UserRegistrationField field) {

        System.out.print("Field # " + index + ": ");
        System.out.print("\n\tname: " + field.getName());
        System.out.print("\n\tform name: " + field.getFormName());
        System.out.print("\n\tvalue: " + field.getValue());
        System.out.print("\n\ttype: " + field.getComponentType());
        System.out.print("\n\tmandatory: " + field.getMandatory());
        System.out.print("\n\tmaxLength: " + field.getMaxLength());

        Vector<String> allowedValues = field.getAllowedValues();
        if (allowedValues != null && allowedValues.size() > 0) {

            System.out.print("\n\tallowed values: ");

            for (int i = 0; i < allowedValues.size(); i++) {
                System.out.print("\n\t\tallowed value: " + allowedValues.get(i));
            }
        }

        System.out.println();
    }

    /**
     * Функция вывода статуса регистрации пользователя.
     *
     * @param userStatus Статус пользователя.
     */
    private static void printCA15UserRegisterInfoStatus(CA15UserRegisterInfoStatus
        userStatus) {

        System.out.println("Status: " + userStatus.toString());
        System.out.println("TokenID: " + userStatus.getTokenID());
        System.out.println("Password: " + userStatus.getPassword());

    }

    @Override
    public void main() throws Exception {

        // 1. Получаем список полей для заполнения и последующей
        // регистрации пользователя.

        Vector<CA15UserRegistrationField> userRegistrationFields =
            CA15User.getUserRegistrationFields(CA15GostCertificateRequest.TEST_CA15_HTTPS_ADDRESS);

        // Выводим поля.
        for (int i = 0; i < userRegistrationFields.size(); i++) {

            CA15UserRegistrationField userRegistrationField =
                userRegistrationFields.get(i);

            printUserRegistrationFieldInfo(i + 1, userRegistrationField);
        } // for

        // 2. Заполняем полученный список значениями.

        // Список пар поле=значение для передачи на регистрацию.
        Map<String, String> fields = new HashMap<String, String>();

        // Частично заполняем список названиями полей и значениями.
        // Обязательным является только CommonName, а также укажем
        // страну CountryName = RU.

        for (int i = 0; i < userRegistrationFields.size(); i++) {

            CA15UserRegistrationField userRegistrationField =
                    userRegistrationFields.get(i);

            String fieldName = userRegistrationField.getFormName();
            String fieldValue = userRegistrationField.getValue();

            // Подставляем свои значения в CN и C.
            if (fieldName.equalsIgnoreCase("RDN_CN_1")) {
                fieldValue = COMMON_NAME;
            }
            else if (fieldName.equalsIgnoreCase("RDN_C_1")) {
                fieldValue = COUNTRY_NAME;
            } // if

            fields.put(fieldName, fieldValue);
        } // for

        // 3. Регистрируем пользователя и получаем tokenID и пароль
        // для входа.

        CA15User newUser = new CA15User(fields);
        CA15UserRegisterInfoStatus userStatus =
            newUser.registerUser(CA15GostCertificateRequest.TEST_CA15_HTTPS_ADDRESS);

        printCA15UserRegisterInfoStatus(userStatus);

        if (userStatus.getValue() != CA15Status.CR_DISP_ISSUED &&
            userStatus.getValue() != CA15Status.CR_DISP_UNDER_SUBMISSION) {

            System.err.println("User registration failure.");
            return;
        } // if

        // 4. Проверяем статус пользователя, если регистрация не произвелась
        // сразу.

        // Если пользователь в процессе регистрации (UNDER_SUBMISSION), то ждем
        // окончания регистрации, пока запрос будет обработан, проверя статус этого
        // пользователя по его tokenID и паролю, которые мы уже получили.
        // Если запрос был обработан моментально, то выходим из программы, т.к.
        // все необходимые данные были уже распечатаны ранее.
        // Можно организовать процесс ожидания иначе: с помощью цикла опроса состояния
        // обработки и др.
        if (userStatus.getValue() == CA15Status.CR_DISP_UNDER_SUBMISSION) {

            Thread.sleep(30 * 1000);

            CA15User userInfo =
                new CA15User(userStatus.getTokenID(), userStatus.getPassword());

            CA15UserRegisterStatus status = userInfo.checkUserStatus(
                CA15GostCertificateRequest.TEST_CA15_HTTPS_ADDRESS);

            printUserInfo(userInfo, status);

        } // if
    }
}
