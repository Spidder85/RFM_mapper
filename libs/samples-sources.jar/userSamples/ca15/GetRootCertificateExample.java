/**
 * Copyright 2004-2012 Crypto-Pro. All rights reserved.
 * Программный код, содержащийся в этом файле, предназначен
 * для целей обучения. Может быть скопирован или модифицирован
 * при условии сохранения абзацев с указанием авторства и прав.
 *
 * Данный код не может быть непосредственно использован
 * для защиты информации. Компания Крипто-Про не несет никакой
 * ответственности за функционирование этого кода.
 */
package userSamples.ca15;

import ru.CryptoPro.JCP.Util.JCPInit;
import ru.CryptoPro.JCPRequest.ca15.request.CA15GostCertificateRequest;

import java.security.cert.Certificate;
import java.security.cert.X509Certificate;

/**
 * Пример получения списка корневых сертификатов УЦ (CA15).
 *
 * 10/11/2012
 *
 */
public class GetRootCertificateExample extends CAConfiguration {

    /**
     * Конструктор.
     *
     * @param needInit Флаг необходимости выполнить
     * инициализацию.
     */
    protected GetRootCertificateExample(boolean needInit) {
        super(needInit);
    }

    /**
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        JCPInit.initProviders(false);
        final GetRootCertificateExample example = new GetRootCertificateExample(true);
        example.main();

    }

    @Override
    public void main() throws Exception {

        // Получаем список сертификатов.
        Certificate[] rootCerts = CA15GostCertificateRequest
            .getRootCertList(CA15_ADDRESS_HTTP);

        if (rootCerts != null) {

            // Выводим сертификаты на экран.
            for (int i = 0; i < rootCerts.length; i++) {

                X509Certificate cert = (X509Certificate) rootCerts[i];
                System.out.println("Root certificates (CA15): " +
                    "\n\tserial number: " + cert.getSerialNumber().toString(16) +
                    "\n\tsubject: " + cert.getSubjectDN() +
                    "\n\tissuer: " + cert.getIssuerDN());
            } // for
        } // if
    }
}
