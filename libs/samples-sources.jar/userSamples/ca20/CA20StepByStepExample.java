/**
 * $RCSfileCA20StepByStepExample.java,v $
 * version $Revision: 36379 $
 * created 06.07.2015 10:42 by afevma
 * last modified $Date: 2012-05-30 12:19:27 +0400 (Ср, 30 май 2012) $ by $Author: afevma $
 * <br>
 * Copyright 2004-2015 Crypto-Pro. All rights reserved.
 * Программный код, содержащийся в этом файле, предназначен
 * для целей обучения. Может быть скопирован или модифицирован
 * при условии сохранения абзацев с указанием авторства и прав.
 * <p>
 * Данный код не может быть непосредственно использован
 * для защиты информации. Компания Крипто-Про не несет никакой
 * ответственности за функционирование этого кода.
 */
package userSamples.ca20;

import com.objsys.asn1j.runtime.Asn1DerEncodeBuffer;
import com.objsys.asn1j.runtime.Asn1Integer;
import com.objsys.asn1j.runtime.Asn1ObjectIdentifier;
import com.objsys.asn1j.runtime.Asn1OctetString;

import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.util.CollectionStore;

import ru.CryptoPro.CAdES.CAdESSignature;
import ru.CryptoPro.CAdES.CAdESType;

import ru.CryptoPro.Crypto.CryptoProvider;

import ru.CryptoPro.JCP.ASN.CA_Definitions.CertificateTemplate;
import ru.CryptoPro.JCP.ASN.PKIX1Explicit88.Extension;
import ru.CryptoPro.JCP.JCP;
import ru.CryptoPro.JCP.KeyStore.ContainerStore;
import ru.CryptoPro.JCP.KeyStore.JCPPrivateKeyEntry;
import ru.CryptoPro.JCP.KeyStore.StoreInputStream;
import ru.CryptoPro.JCP.Util.JCPInit;
import ru.CryptoPro.JCP.params.JCPProtectionParameter;
import ru.CryptoPro.JCP.params.OID;
import ru.CryptoPro.JCP.tools.Encoder;
import ru.CryptoPro.JCP.tools.Platform;

import ru.CryptoPro.JCPRequest.ca20.decoder.*;
import ru.CryptoPro.JCPRequest.ca20.request.CA20GostCertificateRequest;
import ru.CryptoPro.JCPRequest.ca20.status.CA20RequestStatus;
import ru.CryptoPro.JCPRequest.ca20.status.CA20Status;
import ru.CryptoPro.JCPRequest.ca20.status.CA20UserRegisterInfoStatus;
import ru.CryptoPro.JCPRequest.ca20.user.CA20AuxiliaryUserInfo;
import ru.CryptoPro.JCPRequest.ca20.user.CA20CertAuthUser;
import ru.CryptoPro.JCPRequest.ca20.user.CA20User;

import userSamples.ca15.CAConfiguration;
import util.ResolveProvider;

import java.io.*;

import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import java.util.*;

/**
 * Пример взаимодействия с УЦ 2.0 (CA20). В примере есть ряд
 * упрощений и отсутствуют проверки статусов на ошибки.
 * Более полное описание можно найти в разделе "3. HTTP интерфейс
 * веб приложений" документа "ПАК КриптоПро УЦ 2.0. Руководство
 * программиста" дистрибутива ПАК КриптоПро УЦ 2.0.
 *
 * JCP-387: пока нет внещнего тестового УЦ 2.0 - пример не работает!
 * @author Copyright 2004-2015 Crypto-Pro. All rights reserved.
 * @version 2.5
 */
public class CA20StepByStepExample extends CAConfiguration {

    private SecureRandom userNameRandom = null;
    /**
     * Шаблон сертификата по умолчанию: пользователь. Должен быть
     * получен из {@link #getUserCertificateTemplates(String, CA20User)}.
     */
    public static final String CA20_TEMPLATE_USER = "1.2.643.2.2.46.0.8";

    /**
     * Дополнительная информация для регистрации пользователя.
     */
    public static final CA20AuxiliaryUserInfo USER_INFO = new CA20AuxiliaryUserInfo(
        "comment", "description", "test@cryptopro.ru", "key phrase");

    /**
     * Конструктор.
     *
     * @param needInit Флаг необходимости выполнить
     * инициализацию. По умолчанию - true.
     */
    public CA20StepByStepExample(boolean needInit) {

        super(needInit);

        try {
            userNameRandom = SecureRandom.getInstance("CPRandom");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Random generator failure!");
        }

    }

    /**
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        JCPInit.initProviders(false);
        final CA20StepByStepExample example = new CA20StepByStepExample(true);
        example.main();

    }

    @Override
    public void main() throws Exception {

        // executeOne(JCP.GOST_EL_DH_NAME,    JCP.GOST_EL_SIGN_NAME);
        executeOne(JCP.GOST_DH_2012_256_NAME, JCP.GOST_SIGN_2012_256_NAME);
        executeOne(JCP.GOST_DH_2012_512_NAME, JCP.GOST_SIGN_2012_512_NAME);

    }

    /**
     * Выполнение конкретного примера с использованием
     * заданных алгоритмов ключа и подписи и заполненного
     * списка полей для регистрации пользователя.
     * Используется для упрощения запуска примера.
     *
     * @param keyAlgorithm Алгоритм ключа. Может не подходить в
     * том случае, если значение KeySpec, как типа ключа, в шаблоне
     * сертификата не совпадает с ним.
     * @param signatureAlgorithm Алгоритм подписи.
     * @throws Exception
     */
    public void executeOne(String keyAlgorithm,
        String signatureAlgorithm) throws Exception {

        execute(
            CA20_ADDRESS,
            CS20_USER_FOLDER,
            getRegFields(calculateNewCA15UserName()),
            USER_INFO,
            CA20_TEMPLATE_USER,
            keyAlgorithm,
            CryptoProvider.PROVIDER_NAME,
            signatureAlgorithm,
            JCP.PROVIDER_NAME,
            JCP.HD_STORE_NAME,
            false,
            true,
            TRUST_STORE,
            TRUST_STORE_PASSWORD.toCharArray(),
            null // тут нужны сертификаты - промежуточный и корневой УЦ - цепочки для сертификата клиента
        );

    }

    /**
     * Функция создания DN имени для регистрации нового пользователя.
     * Для регистрации необходимо только CN имя. Будет использоваться
     * при формировании запроса.
     *
     * @return имя для регистрации пользователя.
     */
    protected String calculateNewCA15UserName() {

        String newUserName = null;
        final int USERNAME_LENGTH = 16;
        final byte[] byteArray = new byte[USERNAME_LENGTH];

        // Генерируем случайное число.
        userNameRandom.nextBytes(byteArray);
        userNameRandom.setSeed(byteArray);

        // Конвертируем число в строку.
        BigInteger bi = new BigInteger(byteArray);
        newUserName = bi.toString(16);

        if (newUserName.charAt(0) == '-') {
            newUserName = newUserName.substring(1);
        }

        System.out.println("Current calculated user name: " + newUserName);
        return newUserName;
    }

    /**
     * Функция формирования списка из промежуточного и
     * корневого сертификатов для установки в контейнер
     * клиента в случае выпуска сертификата в УЦ, т.к.
     * это требуется для выбора контейнера по issuers.
     *
     * @return список сертификатов.
     * @throws Exception
     */
    protected static X509Certificate[] getAdditionalCertsForTestCA2012()
        throws Exception {

        CertificateFactory factory = CertificateFactory.getInstance("X.509");

        final X509Certificate intermediateCert = (X509Certificate)
            factory.generateCertificate(new FileInputStream(CERT_STORE + "intermediateCert.cer"));

        final X509Certificate rootCert = (X509Certificate)
            factory.generateCertificate(new FileInputStream(CERT_STORE + "rootCert.cer"));

        return new X509Certificate[] { intermediateCert, rootCert };

    }

    /**
     * Получение списка (фиксированного) полей для регистрации
     * пользователя. Они должны определяться и заполняться после
     * выполнения запроса {@link #getUserRegistrationFields(String, String)},
     * но известно, что эти два поля (CommonName и Country) точно
     * будут присутствовать в списке, поэтому, чтобы не усложнять
     * код, сразу используем именно их, меняя только имя пользователя,
     * и составляем свой список.
     *
     * @param userName Имя пользователя.
     * @return список заполненных полей для регистрации
     * пользователя.
     */
    private static Map<String, String> getRegFields(String userName) {


        final Map<String, String> regFields = new HashMap<String, String>();

        regFields.put("2.5.4.3", userName);
        regFields.put("2.5.4.6", "RU");

        regFields.put("2.5.4.8", "Россия");
        regFields.put("2.5.4.7", "Москва");
        regFields.put("2.5.4.10", "ООО \"КРИПТО-ПРО\"");
        regFields.put("2.5.4.11", "JCP");
        regFields.put("1.2.840.113549.1.9.1", "afevma@cryptopro.ru");

        return regFields;
    }

    /**
     * Выполнение полного примера регистрации пользователя, отправки
     * запроса на сертификат, получения сертификата и его установки,
     * получения списков запросов и сертификатов и др.
     *
     * @param address Адрес УЦ (CA20).
     * @param folder Папка пользователя.
     * @param regFields Фиксированные для данного примера поля
     * для регистрации пользователя и формирования Subject в
     * запросе на сертификат.
     * @param userInfo Дполнительная информация для регистрации
     * пользователя.
     * @param actualTemplateOid Используемый шаблон сертификата. Должен
     * быть добавлен в запрос (и в сертификат в итоге).
     * @param keyAlgorithm Алгоритм ключа. Может не подходить в
     * том случае, если значение KeySpec ( типа ключа) в шаблоне
     * сертификата не совпадает с ним.
     * @param signatureAlgorithm Алгоритм подписи запроса.
     * @param signatureProvider Провайдер подписи запроса.
     * @param storeType Тип контейнера.
     * @param isServer True, если сертификат должен использоваться для
     * аутентификации сервера (с соответствующим шаблоном).
     * @param notifyAboutInstallation True, если следует отправлять
     * уведомление об установке сертификата и поменять способ авторизации
     * (с авторизации по токену/паролю к авторизации по сертификату).
     * @param trustStorePath Файл хранилища доверенных сертификатов.
     * Используется в случае смены способа авторизации (с помощью сертификата).
     * @param trustStorePassword Пароль для доступа к хранилищу
     * сертификатов.
     * @param additionalCerts Дополнительные сертификаты - промежуточные,
     * корневой, чтобы построить цепочку. Может быть null.
     * @return зарегистрированный пользователь.
     * @throws Exception
     */
    public CA20User execute(String address, String folder, Map<String, String>
        regFields, CA20AuxiliaryUserInfo userInfo, String actualTemplateOid,
        String keyAlgorithm, String keyProvider, String signatureAlgorithm,
        String signatureProvider, String storeType, boolean isServer, boolean
        notifyAboutInstallation, String trustStorePath, char[] trustStorePassword,
        X509Certificate[] additionalCerts) throws Exception {

        // 1. Получение списка полей для регистрации пользователя.
        // Выполняется для проверки примера, результат не используется,
        // хотя должен анализироваться и фильтроваться перед передачей
        // в {@link registerUser(String, String, Map<String, String>,
        // CA20AuxiliaryUserInfo)}. Используется заранее зафиксированный
        // список полей, чтобы упростить код здесь.

        getUserRegistrationFields(address, folder);

        // 2. Вместо использования и проверки полей fields сразу прибегнем
        // к использованию фиксированного списка полей {@link #getRegFields(String)}.

        final CA20UserRegisterInfoStatus regUserStatus = registerUser(
            address, folder, regFields, userInfo);

        // В дальнейшем по умолчанию этот новый пользователь
        // авторизуется по своим токену и паролю.

        CA20User ca20User = new CA20User(regUserStatus.getTokenID(),
            regUserStatus.getPassword(), folder);

        // 3. Проверка статуса регистрации пользователя. Пользователь
        // считается зарегистрированным, если статус Complete.

        if (!regUserStatus.getStatus().equalsIgnoreCase(CA20Status.STATUS_REQUEST_C)) {

            boolean statusComplete = false;
            int counter = 5; // 60

            while (counter > 0) {

                Thread.sleep(1000);
                counter--;

                // Проверка статуса регистрации.
                final CA20Status userStatus = checkUserStatus(address, ca20User);
                System.out.println(userStatus);

                // Если регистрация выполнена, то продолжаем.
                if (userStatus.getStatus().equalsIgnoreCase(CA20Status.STATUS_REQUEST_C)) {
                    statusComplete = true;
                    break;
                } // if

            } // while

            if (!statusComplete) {
                // throw new Exception("Hmm... Still not complete?");
                System.err.println("Hmm... Still not complete? Trying to continue...");
                // пробуем продолжить
            } // if

        } // if

        // 4. Получение списка шаблонов сертификатов в папке пользователя.
        // Шаблоны нужны для создания запросов на сертификаты.

        final Vector<CA20GostTemplateField> templates =
            getUserCertificateTemplates(address, ca20User);

        // Найдем в списке заранее известный шаблон,
        // который будем использовать. Он уже зафиксирован, но
        // необходим объект класса {@link #CA20GostTemplateField}.

        CA20GostTemplateField actualTemplate = null;

        for (CA20GostTemplateField template : templates) {
            if (template.getOid().equalsIgnoreCase(actualTemplateOid)) {
                actualTemplate = template;
                break;
            } // if
        } // for

        if (actualTemplate == null) {
            throw new Exception("Hmm... Actual template not found!");
        } // if

        // 5. Создание запроса на сертификат пользователя, отправка
        // его в УЦ, создание ключевого контейнера.

        // Запрос содержит те же поля, что и пользователь при регистрации.
        final String subjectNameString = convertRegFieldsToSubject(regFields);

        // Будущие алиас ключа...
        final String keyAlias = ca20User.getTokenID();

        //...и пароль.
        final String keyPassword = ca20User.getPassword();

        System.out.println("Key alias: " + keyAlias +
            ", key password: " + keyPassword);

        // Важно учитывать, что шаблон {@link #CA20GostTemplateField}
        // содержит поле keySpec, определяющее тип ключа, который
        // можно генерировать с этим шаблоном. Далее в этом примере
        // предполагается, что можно создавать ключ обмена с указанным
        // шаблоном (пользователь). Полученный статус будет содержать
        // идентификатор запроса на сертификат.

        final CA20RequestStatus certRequestStatus = generateAndSendCertificateRequest(
            address, ca20User, subjectNameString, isServer, keyAlias, keyPassword.toCharArray(),
            actualTemplate, keyAlgorithm, keyProvider, signatureAlgorithm, signatureProvider,
            storeType, null, null, false, additionalCerts);

        // Идентификатор запроса на сертификат.
        final String certRequestId = certRequestStatus.getCertRequestId();

        // 6. Проверка статуса обработки запроса на сертификат. Запрос
        // считается обработанным, если статус Complete.

        if (!certRequestStatus.getStatus().equalsIgnoreCase(CA20Status.STATUS_REQUEST_C)) {

            boolean statusComplete = false;
            int counter = 5; // 60

            while (counter > 0) {

                Thread.sleep(1000);
                counter--;

                // Проверка статуса запроса на сертификат.
                final CA20RequestStatus requestStatus = checkCertificateStatus(address,
                        ca20User, certRequestId);

                System.out.println(requestStatus);

                // Если обработка выполнена, то продолжаем.
                if (requestStatus.getStatus().equalsIgnoreCase(CA20Status.STATUS_REQUEST_C)) {
                    statusComplete = true;
                    break;
                } // if

            } // while

            if (!statusComplete) {
                // throw new Exception("Hmm... Still not complete?");
                System.err.println("Hmm... Still not complete? Trying to continue...");
                // пробуем продолжить
            } // if

        } // if

        // 7. Получение сертификата пользователя по идентификатору
        // запроса на сертификат, результат не используется. Сертификат
        // сразу устанавливается в контейнер.

        getCertificateByRequestId(address, ca20User, storeType,
            signatureProvider, keyAlias, keyPassword, certRequestId);

        // 8. Отправка уведомления (рекомендуется) о том, что сертификат
        // пользователя установлен в контейнер. Ответом должен быть статус
        // "K". После отправки такого уведомления необходимо перейти от
        // авторизации с помощью токена и пароля к авторизации с использованием
        // сертификата пользователя. Если не отправлять это уведомление, то можно
        // продолжить использовать токен и пароль (не рекомендуется).

        if (notifyAboutInstallation) {

            System.out.println("Notify CA about installation...");

            final CA20RequestStatus installedCertStatus = markCertificateInstalled(
                address, ca20User, certRequestId);

            if (!installedCertStatus.getStatus().equalsIgnoreCase(CA20Status.STATUS_REQUEST_K)) {
                throw new Exception("Hmm... Bad response about installed certificate!");
            } // if

            // Раз уведомление отправлено, сменим способ авторизации.
            // Помимо хранилища доверенных сертификатов, которое уже
            // используется в static {} секции в классе-предке примера,
            // потребуется пароль к контейнеру данного пользователя.

            final CA20CertAuthUser authUser = getCA20UserAuthorizedByCertificate(
                trustStorePath, trustStorePassword, storeType, signatureProvider,
                    keyAlias, keyPassword, folder);

            // Эти данные могут пригодиться, так как, возможно,
            // придется удалять контейнер, а его алиас - это токен,
            // пароль - пароль пользователя.

            authUser.setTokenID(ca20User.getTokenID());
            authUser.setPassword(ca20User.getPassword());

            ca20User = authUser;

        } // if

        // 9. Получение списка запросов на сертификаты пользователя.
        // Выполняется для проверки примера, результат не используется.

        getCertificateRequestList(address, ca20User);

        // 10. Получение списка сертификатов пользователя. Выполняется
        // для проверки примера, результат не используется.

        getCertificateList(address, ca20User);

        // 11. Получение списка запросов на отзыв сертификатов
        // пользователя. Выполняется для проверки примера, результат
        // не используется (и, скорее всего, пуст).

        getRequestRevocationList(address, ca20User);

        // 12. Получение зарегистрированного пользователя.

        return ca20User;

    }

    /**
     * Формирование subject name в виде строки из списка полей
     * regFields, т.е. фактически из результатов
     * {@link #getUserRegistrationFields(String, String)}, для
     * передачи в запрос на сертификат.
     *
     * @param regFields Список полей вида oid=value.
     * @return строка для Subject.
     */
    public static String convertRegFieldsToSubject(Map<String, String> regFields) {

        final StringBuilder subjectName = new StringBuilder();
        final Set<Map.Entry<String, String>> regFieldsSet = regFields.entrySet();

        final Iterator<Map.Entry<String, String>> regFieldsIterator = regFieldsSet.iterator();
        while (regFieldsIterator.hasNext()) {

            final Map.Entry<String, String> entry = regFieldsIterator.next();
            subjectName.append(entry.getKey());

            subjectName.append("=");
            subjectName.append(entry.getValue());

            if (regFieldsIterator.hasNext()) {
                subjectName.append(",");
            } // if

        } // while

        return subjectName.toString();

    }

    /**
     * Получения списка полей и их описания для регистрации
     * пользователя в его папке.
     * Авторизация не требуется.
     *
     * @param address Адрес УЦ (CA20).
     * @param folder Папка пользователя.
     * @return список полей.
     * @throws Exception
     */
    public static Vector<CA20UserRegistrationField> getUserRegistrationFields(
        String address, String folder) throws Exception {

        final Vector<CA20UserRegistrationField> fields = CA20User.
            getUserRegistrationFields(address, folder);

        for (CA20UserRegistrationField field : fields) {
            System.out.println(field);
        } // for

        return fields;

    }

    /**
     * Регистрация пользователя в его папке с помощью заполненных
     * полей и дополнительной информации.
     * Авторизация не требуется.
     *
     * @param address Адрес УЦ (CA20).
     * @param folder Папка пользователя.
     * @param fields Список заполненных полей для регистрации.
     * @param userInfo Дполнительная информация.
     * @return статус регистрации, а также токен и пароль.
     * @throws Exception
     */
    public static CA20UserRegisterInfoStatus registerUser(
        String address, String folder, Map<String, String> fields,
        CA20AuxiliaryUserInfo userInfo) throws Exception {

        final CA20User user = new CA20User(fields, folder);
        final CA20UserRegisterInfoStatus status = user.registerUser(address, userInfo);

        System.out.println(status);
        return status;

    }

    /**
     * Проверка статуса регистрации пользователя.
     * Требуется авторизация.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Проверяемый пользователь.
     * @return статус регистрации.
     * @throws Exception
     */
    public static CA20Status checkUserStatus(String address, CA20User user)
        throws Exception {

        final CA20Status status = user.checkUserStatus(address);
        System.out.println(status);

        System.out.println(CA20Status.getDescriptionByStatus(status.getStatus(),
            CA20Status.StatusGroup.sgRequest));

        return status;

    }

    /**
     * Получение из папки пользователя списка шаблонов сертификатов,
     * поддерживаемых УЦ.
     * Требуется авторизация.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь, из папки которого получаем шаблоны.
     * @return список шаблонов.
     * @throws Exception
     */
    public static Vector<CA20GostTemplateField> getUserCertificateTemplates(
        String address, CA20User user) throws Exception {

        final Vector<CA20GostTemplateField> templates = user.
            getUserCertificateTemplates(address);

        for (CA20GostTemplateField template : templates) {
            System.out.println(template);
        } // for

        return templates;

    }

    /**
     * Создание ключевой пары, запроса на сертификат пользователя с
     * указанием шаблона и алгоритма ключа с последующей отправкой в
     * УЦ. После отправки запроса происходит сохранение ключевого
     * контейнера и запись в него временной заглушки в виде
     * самодподписанного сертификата, который в будущем будет заменен
     * выпущенным сертификатом.
     * Требуется авторизация.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь УЦ, для которого создается сертификат.
     * @param subject Владелец сертификата (соответствует списку полей,
     * использовавшихся при регистрации пользователя).
     * @param isServer True, если сертификат должен использоваться для
     * аутентификации сервера.
     * @param savingAlias Алиас ключа для сохранения ключевого контейнера
     * пользователя.
     * @param savingPassword Пароль для сохранения ключевого контейнера
     * пользователя.
     * @param template Выбранный шаблон сертификата.
     * @param keyAlgorithm Алгоритма ключа.
     * @param signatureAlgorithm Алгоритм подписи.
     * @param signatureProvider Провайдер подписи запроса.
     * @param signingAlias Алиас ключа подписи. Если null, то подпись
     * запроса выполняется текущим сгенерированным ключом.
     * @param signingPassword Пароль к ключу подписи.
     * @param doubleSignedForInternal True, если нужно поставить вторую
     * подпись для автоматического подтверждения запроса. Только для внутреннего
     * использования! По умолчанию - false.
     * @param additionalCerts Дополнительные сертификаты - промежуточные,
     * корневой, чтобы построить цепочку. Может быть null.
     * @return статус обработки запроса на сертификат.
     * @throws Exception
     */
    public static CA20RequestStatus generateAndSendCertificateRequest(
        String address, CA20User user, String subject, boolean isServer,
        String savingAlias, char[] savingPassword, CA20GostTemplateField
        template, String keyAlgorithm, String keyProvider, String signatureAlgorithm,
        String signatureProvider, String storeType, String signingAlias,
        char[] signingPassword, boolean doubleSignedForInternal, X509Certificate[]
        additionalCerts) throws Exception {

        // Генерация ключевой пары.
        System.out.println("Generating and sending certificate request...");

        final CA20GostCertificateRequest req = new CA20GostCertificateRequest(signatureProvider);
        final KeyPairGenerator kg = KeyPairGenerator.getInstance(keyAlgorithm, keyProvider);

        final KeyPair pair = kg.generateKeyPair();
        req.init(keyAlgorithm, isServer);

        req.setPublicKeyInfo(pair.getPublic());
        req.setSubjectInfo(subject);

        // Формирование расширения с указанием выбранного шаблона.

        final String szOID_CERTIFICATE_TEMPLATE = "1.3.6.1.4.1.311.21.7"; // OID расширения в запросе
        final OID OID_CERTIFICATE_TEMPLATE = new OID(szOID_CERTIFICATE_TEMPLATE);

        final OID selectedTemplateOid = new OID(template.getOid());

        // Формат: {oid_шаблона=>oid, версия_1=>1, версия_0=>0}.
        final CertificateTemplate certificateTemplate = new CertificateTemplate(
            new Asn1ObjectIdentifier(selectedTemplateOid.value),
                new Asn1Integer(1), new Asn1Integer(0));

        final Asn1DerEncodeBuffer buffer = new Asn1DerEncodeBuffer();
        certificateTemplate.encode(buffer);

        final byte[] encodedCertificateTemplate = buffer.getMsgCopy();

        final Asn1OctetString certificateTemplateValue = new
            Asn1OctetString(encodedCertificateTemplate);

        final Extension templateExtension = new Extension(new Asn1ObjectIdentifier(
            OID_CERTIFICATE_TEMPLATE.value), certificateTemplateValue);

        req.addExtension(templateExtension);

        // Подпись созданного запроса сгенерированным ключом.

        req.encodeAndSign(pair.getPrivate(), signatureAlgorithm);
        byte[] reqEncoded = req.getEncoded();

        // Если пользователь уже имеет сертификат, с помощью
        // которого авторизуется (т.е. уже было уведомление об
        // установке и т.п.), значит, подписываем запрос и
        // вкладываем в PKCS#7 сообщение с подписью на ключе
        // авторизованного пользователя.

        if (signingAlias != null) {

            // Когда выпускается второй и более сертификат авторизованного
            // пользователя, то запрос должен быть вложен в PKCS#7 с подписью
            // данного авторизованного пользователя.

            // Читаем ключ подписи авторизованного пользователя и
            // его сертификат.

            final KeyStore keyStore = KeyStore.getInstance(storeType, signatureProvider);
            keyStore.load(null, null);

            final PrivateKey signingPrivateKey;
            if (signatureProvider.equalsIgnoreCase(ResolveProvider.ALTERNATIVE_PROVIDER)) {

                JCPProtectionParameter parameter = new JCPProtectionParameter(signingPassword);
                JCPPrivateKeyEntry entry = (JCPPrivateKeyEntry) keyStore.getEntry(signingAlias, parameter);

                signingPrivateKey = entry.getPrivateKey();

            } // if
            else {
                signingPrivateKey = (PrivateKey) keyStore.getKey(signingAlias, signingPassword);
            } // else

            final X509Certificate signingCertificate = (X509Certificate) keyStore
                .getCertificate(signingAlias);

            System.out.println("Current time: " + Calendar.getInstance().getTime());
            System.out.println("Signing certificate: " + signingCertificate);

            // Формируем PKCS#7 (CAdES-BES) сообщение с подписью
            // авторизованного пользователя с запросом внутри и
            // приложенным сертификатом подписи.

            System.out.println("Sign...");
            CAdESSignature cAdESSignature = new CAdESSignature();

            List<X509Certificate> chain = new ArrayList<>();
            chain.add(signingCertificate);

            if (additionalCerts != null) {
                for (X509Certificate ac : additionalCerts) {
                    chain.add(ac);
                }
            } // if

            cAdESSignature.addSigner(
                signatureProvider,
                null,
                null,
                signingPrivateKey,
                chain,
                CAdESType.CAdES_BES,
                null,
                false,
                null,
                null,
                null,
                true // add chain
            );

            ByteArrayOutputStream outSignatureStream = new ByteArrayOutputStream();
            cAdESSignature.open(outSignatureStream);

            cAdESSignature.update(reqEncoded);
            cAdESSignature.close();

            outSignatureStream.close();
            reqEncoded = outSignatureStream.toByteArray();

            // Для внутреннего использования (установка второй подписи)!
            // Автоматическое подтверждение запроса (Q -> A -> C).

            if (doubleSignedForInternal) {

                System.out.println("Sign again...");
                cAdESSignature = new CAdESSignature();

                cAdESSignature.addSigner(
                    signatureProvider,
                    null,
                    null,
                    signingPrivateKey,
                    chain,
                    CAdESType.CAdES_BES,
                    null,
                    false,
                    null,
                    null,
                    null,
                    true // add chain
                );

                outSignatureStream = new ByteArrayOutputStream();
                cAdESSignature.open(outSignatureStream);

                cAdESSignature.update(reqEncoded);
                cAdESSignature.close();

                outSignatureStream.close();
                reqEncoded = outSignatureStream.toByteArray();

            } // if

        } // else

        // Сохранение контейнера, установка в него временной
        // заглушки (самоподписанный сертификат) до момента
        // получения сертификата пользователя из УЦ.

        final KeyStore keyStore = KeyStore.getInstance(storeType, signatureProvider);
        keyStore.load(null, null);

        final byte[] selfSigned = req.getEncodedSelfCert(pair,
            subject, signatureAlgorithm);

        // Заглушка.

        CertificateFactory factory = CertificateFactory.getInstance("X.509");
        final Certificate selfCert = factory.generateCertificate(new ByteArrayInputStream(selfSigned));

        // Можем установить и промежуточные с корневым сертификатом,
        // чтобы и после замены сертификата клиента они оставались в
        // контейнере. Они требутся при подключении по TLS к УЦ с
        // использованием аутентификации по сертификату, при этом
        // сервер шлет список issuers с корневым,  не промежуточным,
        // которым выдан клиентский сертификат. Чтобы клиентский
        // сертификат был выбран по issuers, нужно поместить в контейнер
        // всю цепочку. Если сертификат клиента не имеет промежуточных
        // сертификатов, то цепочку можно не формировать.

        int size = 1 + (additionalCerts != null ? additionalCerts.length : 0);
        X509Certificate[] chain = new X509Certificate[size];

        chain[0] = (X509Certificate) selfCert;

        if (additionalCerts != null) {
            System.arraycopy(additionalCerts, 0, chain, 1, additionalCerts.length);
        }

        JCPPrivateKeyEntry entry = new JCPPrivateKeyEntry(pair.getPrivate(), chain);
        JCPProtectionParameter parameter = new JCPProtectionParameter(savingPassword);

        keyStore.setEntry(savingAlias, entry, parameter);

        // Отправка запроса на сертификат.

        final Encoder encoder = new Encoder();
        System.out.println(encoder.encode(reqEncoded));

        final CA20RequestStatus status = CA20GostCertificateRequest.
            sendCertificateRequest(address, user, reqEncoded);

        System.out.println(status);

        System.out.println(CA20Status.getDescriptionByStatus(
            status.getStatus(), CA20Status.StatusGroup.sgRequest));

        return status;

    }

    /**
     * Проверка статуса обработки запроса на сертификат по
     * его идентификатору.
     * Требуется авторизация.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь УЦ.
     * @param userCertReqId Идентификатор запроса на сертификат.
     * @return статус обработки запроса.
     * @throws Exception
     */
    public static CA20RequestStatus checkCertificateStatus(String address,
        CA20User user, String userCertReqId) throws Exception {

        final CA20RequestStatus status = CA20GostCertificateRequest.
            checkCertificateStatus(address, user, userCertReqId);

        System.out.println(status);
        return status;

    }

    /**
     * Получение сертификата пользователя по его идентификатору.
     * После получения производится установка сертификата в контейнер
     * пользователя. В случае использования типа хранилища отделяемого
     * носителя в setCertificateEntry потребуется передать пароль в
     * формате alias::::password вместо alias.
     * Требуется авторизация.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь УЦ.
     * @param storeType Тип контейнера.
     * @param provider Провайдер контейнера.
     * @param alias Алиас ключа для сохранения сертификата в ключевой
     * контейнер пользователя.
     * @param password Пароль к контейнеру.
     * @param userCertReqId Идентификатор запроса.
     * @return сертификат.
     * @throws Exception
     */
    public static X509Certificate getCertificateByRequestId(String address,
        CA20User user, String storeType, String provider, String alias,
        String password, String userCertReqId) throws Exception {

        final byte[] certContent = CA20GostCertificateRequest.
            getCertificateByRequestId(address, user, userCertReqId);

        final X509Certificate userCert = (X509Certificate) CertificateFactory
            .getInstance("X.509").generateCertificate(new ByteArrayInputStream(certContent));

        System.out.println("$$ User certificate $$");
        System.out.println("Serial number: " + userCert.getSerialNumber().toString(16));

        System.out.println("Subject: " + userCert.getSubjectDN());
        System.out.println("Public key algorithm: " + userCert.getPublicKey().getAlgorithm());

        System.out.println(userCert);

        final KeyStore keyStore = KeyStore.getInstance(storeType, provider);
        keyStore.load(null, null);

        keyStore.setCertificateEntry(alias + ContainerStore.PASSWORD_PREFIX + password, userCert);
        return userCert;

    }

    /**
     * Получение списка всех запросов на сертификаты пользователя.
     * Требуется авторизация.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь УЦ.
     * @return список запросов на сертификаты.
     * @throws Exception
     */
    public static Vector<CA20CertificateRequestRecord> getCertificateRequestList(
        String address, CA20User user) throws Exception {

        final Vector<CA20CertificateRequestRecord> requests =
            CA20GostCertificateRequest.getCertificateRequestList(address, user);

        for (CA20CertificateRequestRecord request : requests) {
            System.out.println(request);
        } // for

        return requests;

    }

    /**
     * Получение списка всех сертификатов пользователя.
     * Требуется авторизация.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь УЦ.
     * @return список сертификатов.
     * @throws Exception
     */
    public static Vector<CA20CertificateRecord> getCertificateList(String
        address, CA20User user) throws Exception {

        final Vector<CA20CertificateRecord> certificates =
            CA20GostCertificateRequest.getCertificateList(address, user);

        for (CA20CertificateRecord certificate : certificates) {
            System.out.println(certificate);
        } // for

        return certificates;

    }

    /**
     * Получение списка всех запросов отзыва сертификатов
     * пользователя.
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь УЦ.
     * @return список запросов отзыва.
     * @throws Exception
     */
    public static Vector<CA20RevocationRecord> getRequestRevocationList(
        String address, CA20User user) throws Exception {

        final Vector<CA20RevocationRecord> revocations =
            CA20GostCertificateRequest.getRequestRevocationList(address, user);

        for (CA20RevocationRecord revocation : revocations) {
            System.out.println(revocation);
        } // for

        return revocations;

    }

    /**
     * Отправка уведомления о том, что сертификат установлен в
     * контейнер пользователя (отправка и получение статуса "K").
     *
     * @param address Адрес УЦ (CA20).
     * @param user Пользователь УЦ.
     * @param userCertReqId Идентификатор установленного сертификата.
     * @return статус обработки уведомления.
     * @throws Exception
     */
    public static CA20RequestStatus markCertificateInstalled(String address,
        CA20User user, String userCertReqId) throws Exception {

        final CA20RequestStatus status = CA20GostCertificateRequest.
            markCertificateInstalled(address, user, userCertReqId);

        System.out.println(status);
        return status;

    }

    /**
     * Создание авторизуемого по сертификату пользователя, уже ранее
     * зарегистрированного в УЦ (CA20), получившего и установившего
     * сертификат.
     *
     * @param trustStorePath Файл хранилища доверенных сертификатов.
     * @param trustStorePassword Пароль к хранилищу сертификатов.
     * @param storeType Тип контейнера.
     * @param provider Провайдер контейнера.
     * @param keyStorePassword Пароль к ключевому контейнеру.
     * @param folder Папка пользователя (в дяе случаев - не нужна).
     * @return авторизуемый пользователь УЦ.
     * @throws Exception
     */
    public static CA20CertAuthUser getCA20UserAuthorizedByCertificate(String
        trustStorePath, char[] trustStorePassword, String storeType, String
        provider, String alias, String keyStorePassword, String folder)
        throws Exception {

        final KeyStore trustStore = KeyStore.getInstance(JCP.CERT_STORE_NAME,
            Platform.isAndroid ? provider : JCP.PROVIDER_NAME);

        trustStore.load(new FileInputStream(trustStorePath), trustStorePassword);
        final KeyStore keyStore = KeyStore.getInstance(storeType, provider);

        // Если имеем дело с Java CSP, то для cpSSL можно передать алиас
        // контейнера, чтобы не перебирать все.

        if (alias != null) {
            keyStore.load(new StoreInputStream(alias), null);
        } // if
        else {
            keyStore.load(null, null);
        } // else

        return new CA20CertAuthUser(keyStore, keyStorePassword,
            trustStore, folder);

    }

}
