/**
 * $RCSfileGetCA20RootCertificateExample.java,v $
 * version $Revision: 36379 $
 * created 06.07.2015 10:09 by afevma
 * last modified $Date: 2012-05-30 12:19:27 +0400 (Ср, 30 май 2012) $ by $Author: afevma $
 * <br>
 * Copyright 2004-2015 Crypto-Pro. All rights reserved.
 * Программный код, содержащийся в этом файле, предназначен
 * для целей обучения. Может быть скопирован или модифицирован
 * при условии сохранения абзацев с указанием авторства и прав.
 *
 * Данный код не может быть непосредственно использован
 * для защиты информации. Компания Крипто-Про не несет никакой
 * ответственности за функционирование этого кода.
 */
package userSamples.ca20;

import ru.CryptoPro.JCPRequest.ca20.request.CA20GostCertificateRequest;
import userSamples.ca15.CAConfiguration;
import ru.CryptoPro.JCP.Util.JCPInit;

import java.security.cert.Certificate;
import java.security.cert.X509Certificate;

/**
 * ример получения списка корневых сертификатов УЦ (CA20).
 *
 * @author Copyright 2004-2015 Crypto-Pro. All rights reserved.
 * @version 2.5
 */
public class GetCA20RootCertificateExample extends CAConfiguration {


    /**
     * Конструктор.
     *
     * @param needInit Флаг необходимости выполнить
     * инициализацию.
     */
    protected GetCA20RootCertificateExample(boolean needInit) {
        super(needInit);
    }

    /**
     *
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        JCPInit.initProviders(false);
        final GetCA20RootCertificateExample example = new GetCA20RootCertificateExample(true);
        example.main();

    }

    @Override
    public void main() throws Exception {

        Certificate[] rootCerts = CA20GostCertificateRequest
            .getRootCertList(CA20_ADDRESS);

        if (rootCerts != null) {

            // Выводим сертификаты на экран.
            for (int i = 0; i < rootCerts.length; i++) {

                X509Certificate cert = (X509Certificate) rootCerts[i];
                System.out.println("Root certificates (CA20): " +
                    "\n\tserial number: " + cert.getSerialNumber().toString(16) +
                    "\n\tsubject: " + cert.getSubjectDN() +
                    "\n\tissuer: " + cert.getIssuerDN());
            } // for

        } // if

    }

}
