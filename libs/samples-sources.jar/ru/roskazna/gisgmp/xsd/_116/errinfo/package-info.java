@javax.xml.bind.annotation.XmlSchema(namespace = "http://roskazna.ru/gisgmp/xsd/116/ErrInfo", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package ru.roskazna.gisgmp.xsd._116.errinfo;
